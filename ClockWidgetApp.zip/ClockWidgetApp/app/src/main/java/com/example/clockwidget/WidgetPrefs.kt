package com.example.clockwidget

import android.content.Context

object WidgetPrefs {
    private const val PREFS_NAME = "clock_widget_prefs"
    private const val KEY_STYLE_PREFIX = "style_"
    private const val KEY_TYPE_PREFIX = "type_"

    fun saveStyle(context: Context, widgetId: Int, style: ClockStyle) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_STYLE_PREFIX + widgetId, style.name)
            .apply()
    }

    fun loadStyle(context: Context, widgetId: Int): ClockStyle {
        val name = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_STYLE_PREFIX + widgetId, null)
        return ClockStyle.fromName(name)
    }

    fun saveType(context: Context, widgetId: Int, type: ClockType) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TYPE_PREFIX + widgetId, type.name)
            .apply()
    }

    fun loadType(context: Context, widgetId: Int): ClockType {
        val name = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TYPE_PREFIX + widgetId, null)
        return ClockType.fromName(name)
    }

    fun deleteAll(context: Context, widgetId: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_STYLE_PREFIX + widgetId)
            .remove(KEY_TYPE_PREFIX + widgetId)
            .apply()
    }
}
