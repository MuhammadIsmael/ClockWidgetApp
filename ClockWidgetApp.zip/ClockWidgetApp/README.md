# Clock Widget (Analog + Digital)

A complete Android Studio project for a home-screen widget showing:
- **Analog clock**: choose from 5 face styles (Classic Black, Red Rim, Blue
  Modern, Sunset Pink, Mint Green) — each with bold numerals, black or
  matching-colored hands, a red/accent second hand, and a **date window**
  (day of month) at the 3 o'clock position, matching the reference photos.
- **Digital clock**: LED-style green time display with AM/PM and a date/day
  line, inspired by the LED alarm-clock reference image.
- A **widget type** setting: show both clocks side by side, analog only, or
  digital only.
- A **settings (gear) button** on the widget itself, so you can change the
  face style or type anytime — not just when you first add it.

By default both halves live side-by-side in one widget and update every second.

## Compatibility

- **Android version**: works on **Android 7.0 (API 24) and up** —
  `minSdk 24` in `app/build.gradle` sets this floor.
- **Samsung One UI**: the widget uses standard adaptive-icon and
  `AppWidgetProvider` APIs, so it resizes correctly on One UI's home-screen
  grid, follows the themed-icon shape Samsung applies, and behaves like any
  other home-screen widget in One UI's widget picker.
- **Samsung lock screen & AOD — experimental, unofficial**: Google removed
  the ability for **third-party** apps to place widgets on the stock
  Android lock screen back in Android 5.0. However, Samsung ships its own,
  *separate*, undocumented mechanism on One UI called the "Face Widget"
  protocol — it's what lets some third-party apps show up under
  **Settings → Lock screen → Widgets** and on the **Always-On-Display** on
  Galaxy devices. This project implements that protocol
  (`FaceWidgetReceiver.kt` + `res/raw/facewidgets.json`), showing a compact
  time + date card there.
  **Important caveats**: this is not a published Google or Samsung API —
  it isn't documented, isn't guaranteed, and Samsung can change or remove
  it in a future One UI update without notice. Availability has also varied
  by One UI version and region (on some versions you may need Good Lock's
  "LockStar" module installed first for the lock-screen widget picker to
  show third-party entries at all — see Settings → Lock screen → Widgets
  after installing the APK). Treat it as a bonus, not a guarantee — the
  home-screen widget is the fully supported experience.

## Changing the clock face and type

- **When first adding it**: a picker screen appears automatically — choose
  a **type** (Analog + Digital, Analog only, or Digital only) at the top,
  and a **face style** (5 options) below it, then tap "Save".
- **Anytime after that**: tap the small gear icon in the top-right corner
  of the widget to reopen the same picker and change either setting.
- On Android 12+, long-pressing the widget also shows a system "Edit"
  option that opens the same picker (via `android:widgetFeatures="reconfigurable"`).

## Why you're getting source code, not a .apk

This sandbox has no Android SDK and no internet access, so it cannot download
build-tools or Gradle and compile a signed `.apk`. This project is 100% ready
to build though.

## Option A: Build the APK in the cloud with GitHub Actions (no software install)

This project includes `.github/workflows/build-apk.yml`, which builds the
APK automatically in GitHub's free cloud runners — you don't need Android
Studio or any local tools.

1. Create a free GitHub account if you don't have one, and create a new
   **empty** repository (public or private).
2. Upload this whole `ClockWidgetApp` folder's contents to that repo
   (via the GitHub web "Add file → Upload files" button, or `git push` if
   you're comfortable with git).
3. Go to the repo's **Actions** tab. A "Build APK" run will start
   automatically (or click **Run workflow** if it doesn't).
4. When it finishes (~2-3 minutes), open the run, scroll to **Artifacts**,
   and download `ClockWidget-debug-apk` — that's your `.apk`, ready to
   install on your phone.

## Option B: Build locally with Android Studio (5 minutes)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this project, then in Android Studio: **File → Open** → select the
   `ClockWidgetApp` folder.
3. Let Gradle sync (Android Studio will auto-download the SDK/Gradle it needs
   the first time — this requires internet).
4. Build the APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find it at `app/build/outputs/apk/debug/app-debug.apk`, or click
   **locate** in the notification that pops up when the build finishes.
6. Copy the APK to your phone and install it (enable "install from unknown
   sources" if prompted), or run it straight from Android Studio with a
   phone connected via USB debugging.

### Command-line alternative (if you have the Android SDK installed)
```
cd ClockWidgetApp
./gradlew assembleDebug
```
(On first run in a fresh project, Android Studio needs to generate the
`gradlew`/`gradlew.bat` wrapper scripts and wrapper jar automatically — just
opening the project in Android Studio once does this for you.)

## Adding the widget to your home screen

The app itself has no real screen — it only supplies the widget. After
installing:
1. Long-press an empty area of your home screen.
2. Tap **Widgets**.
3. Find **Clock Widget**, drag it onto your home screen, resize as you like.

## Customizing

- **Colors**: `app/src/main/res/values/colors.xml`
  (`digital_green`, `digital_red`, `digital_label`).
- **Digital format**: edit `SimpleDateFormat` patterns in
  `ClockWidgetProvider.kt` (e.g. swap the green LED look for red by changing
  `textColor` in `clock_widget.xml` to `@color/digital_red`).
- **Analog face drawing** (numerals, tick marks, hand lengths, date-window
  position/size): `AnalogClockRenderer.kt` — it's a single self-contained
  `Canvas` drawing routine, easy to tweak.
- **Widget size**: `res/xml/clock_widget_info.xml`
  (`minWidth`, `minHeight`, `targetCellWidth/Height`).

## Notes on battery use

The widget refreshes every second (via `AlarmManager`) so the red second
hand and digital seconds stay live, the same way most analog widgets do.
If you'd rather trade the live second hand for better battery life, remove
`scheduleNextTick(...)` calls and rely only on the system's default
`updatePeriodMillis` (currently 30 minutes) in `clock_widget_info.xml`.
